﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileService
{
    internal class File : FileSystemComponent
    {
        public File(string name) : base(name)
        {
        }

        public override void Add(FileSystemComponent component)
        {
            Console.WriteLine("Cannot add to a file.");
        }

        public override void Display(int depth)
        {
            Console.WriteLine(new String('-', depth) + _name);
        }

        public override void Remove(FileSystemComponent component)
        {
            Console.WriteLine("Cannot remove from a file.");
        }
    }
}
