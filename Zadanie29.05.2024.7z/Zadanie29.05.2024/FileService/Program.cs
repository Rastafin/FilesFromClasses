﻿using ApplicationLogger;

var logger = Logger.Instance;