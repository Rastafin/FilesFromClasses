﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileService
{
    public abstract class FileSystemComponent
    {
        protected readonly string _name;

        protected FileSystemComponent(string name)
        {
            _name = name;
        }

        public abstract void Add(FileSystemComponent component);
        public abstract void Remove(FileSystemComponent component);
        public abstract void Display(int depth);
    }
}
