﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileService
{
    internal class Folder : FileSystemComponent
    {
        private readonly List<FileSystemComponent> _components = new List<FileSystemComponent>();

        public Folder(string name) : base(name)
        {
        }

        public override void Add(FileSystemComponent component)
        {
            _components.Add(component);
        }

        public override void Display(int depth)
        {
            Console.WriteLine(new String('-', depth) + _name);
            foreach (var component in _components)
            {
                component.Display(depth + 2);
            }
        }

        public override void Remove(FileSystemComponent component)
        {
            _components.Remove(component);
        }
    }
}
