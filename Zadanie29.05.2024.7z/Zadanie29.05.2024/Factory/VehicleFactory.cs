﻿using ApplicationLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class VehicleFactory : IFactory
    {
        private readonly ILogger _logger;

        public VehicleFactory(ILogger logger)
        {
            _logger = logger;
        }

        public IVehicle Create(string type)
        {
            try
            {
                switch (type.ToLower())
                {
                    case "car":
                        return new Car(_logger);
                    case "bike":
                        return new Bike(_logger);
                    case "truck":
                        return new Truck(_logger);
                    default:
                        throw new ArgumentException("Invalid vehicle type");
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                return null!;
            }
            
        }
    }
}
