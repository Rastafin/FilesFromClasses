﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApplicationLogger;

namespace Factory
{
    internal class Car : IVehicle
    {
        private readonly ILogger _logger;

        public Car(ILogger logger)
        {
            _logger = logger;
        }

        public void Drive()
        {
            _logger.Log("Car is driving");
        }

        public void Stop()
        {
            _logger.Log("Car has stopped");
        }
    }
}
