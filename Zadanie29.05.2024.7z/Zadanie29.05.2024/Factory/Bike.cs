﻿using ApplicationLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class Bike : IVehicle
    {
        private readonly ILogger _logger;

        public Bike(ILogger logger)
        {
            _logger = logger;
        }

        public void Drive()
        {
            _logger.Log("Bike is driving");
        }

        public void Stop()
        {
            _logger.Log("Bike has stopped");
        }
    }
}
