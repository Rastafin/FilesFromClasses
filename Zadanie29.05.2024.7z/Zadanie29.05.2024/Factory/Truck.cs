﻿using ApplicationLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    internal class Truck : IVehicle
    {
        private readonly ILogger _logger;

        public Truck(ILogger logger)
        {
            _logger = logger;
        }

        public void Drive()
        {
            _logger.Log("Truck is driving");
        }

        public void Stop()
        {
            _logger.Log("Truck has stopped");
        }
    }
}
