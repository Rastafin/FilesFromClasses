﻿// See https://aka.ms/new-console-template for more information
using ApplicationLogger;
using Factory;
using System.Runtime.CompilerServices;

var logger = Logger.Instance;

IFactory vehicleFactory = new VehicleFactory(logger);

IVehicle car = vehicleFactory.Create("car");
IVehicle bike = vehicleFactory.Create("bike");
IVehicle truck = vehicleFactory.Create("truck");

car.Drive();
car.Stop();

bike.Drive();
bike.Stop();

truck.Drive();
truck.Stop();

logger.Save("logs.txt");

Console.WriteLine("All actions have been logged.");