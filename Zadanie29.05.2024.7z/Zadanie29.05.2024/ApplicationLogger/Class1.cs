﻿namespace ApplicationLogger
{
    public class Class1
    {

    }
}
