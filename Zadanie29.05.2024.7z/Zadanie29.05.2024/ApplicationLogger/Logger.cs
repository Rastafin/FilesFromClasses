﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogger
{
    public class Logger : ILogger, iSaveable
    {
        private static readonly Lazy<Logger> _instance = new Lazy<Logger>(() => new Logger());
        private readonly List<string> _logs;
        private static readonly object _lock = new object();

        private Logger()
        {
            _logs = new List<string>();
        }

        public static Logger Instance
        {
            get
            {
                return _instance.Value;
            }
        }
        public IList<string> GetLogs()
        {
            lock (_lock)
            {
                return new List<string>(_logs);
            }
        }

        public void Log(string message)
        {
            lock (_lock)
            {
                _logs.Add(message);
            }
        }

        public void Save(string path)
        {
            lock (_lock)
            {
                try
                {
                    File.WriteAllLines(path, _logs);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error saving logs: {ex.Message}");
                }
            }
        }
    }
}
