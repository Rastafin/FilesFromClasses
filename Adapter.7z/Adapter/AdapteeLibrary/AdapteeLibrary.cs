﻿namespace AdapteeLibrary
{
    public sealed class AdapteeLibrary
    {
        public void PrintToConsole()
        {
            Console.WriteLine("Metoda PrintToConsole z biblioteki AdaoteeLibrary");
        }
    }
}
