﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter
{
    internal class Adaptee
    {
        public void Print()
        {
            Console.WriteLine("To jest metoda Print z klasy Adaptee");
        }
    }
}
