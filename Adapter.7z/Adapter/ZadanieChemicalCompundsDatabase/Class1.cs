﻿namespace ZadanieChemicalCompundsDatabase
{
    public class Class1
    {

    }
}
