﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanieChemicalCompundsDatabase
{
    public enum Compounds
    {
        WATER = 1,
        METHANOL = 2,
        ETHANOL = 3,
        BENZENE = 4
    }
}
